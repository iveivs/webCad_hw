import num from "./test"

console.log(`Testing import ${num}`)