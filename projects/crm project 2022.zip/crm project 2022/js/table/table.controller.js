import * as tabView from './table.view.js'
import * as model from './../model.js'


const dataFromLocStor = model.locStorArr

dataFromLocStor.forEach( (e) => {
    tabView.renderTab(e)
})


tabView.elements.tableWrapper.addEventListener('click', (e) => {
    let id = tabView.getID(e.target)
    
    localStorage.setItem('editId', id)
})


tabView.elements.productSelect.addEventListener('input', e => {
    e.preventDefault()
    const findProduct = tabView.elements.productSelect.value
    tabView.getCourseList(findProduct)
})


tabView.elements.btnWrapper.addEventListener('click', (e) => {
    const dataValue = e.target.dataset.value
    tabView.getStatusList(dataValue)
})


tabView.elements.leftBar.addEventListener('click', (e) => {
    const dataValue = e.target.dataset.value
    tabView.getStatusList(dataValue)
})

tabView.showNewOrderCount()








