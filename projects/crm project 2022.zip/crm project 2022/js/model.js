let locStorArr = checkLocalStorage()

function addTask(formData) {
    let id = locStorArr.length > 0 ? locStorArr[locStorArr.length - 1].id + 1 : 1

    const newObj = {
        id,
        date: new Date().toLocaleDateString(),
        status: "new",
        ...formData,
    }
    locStorArr.push(newObj)
    saveToLocalStorage(locStorArr)
}

function saveToLocalStorage(arr) {
    localStorage.setItem('userInfo', JSON.stringify(arr))
}

function getDataArrayLocalStorage() {
    return JSON.parse(localStorage.getItem('userInfo'))
}

function checkLocalStorage() {
    const data = localStorage.getItem('userInfo')
    if(data) {
        return JSON.parse(data)
    } else {
        return []
    }
}


function findDataLocalStorage(id) {
    let arrFromLS = JSON.parse(localStorage.getItem('userInfo'))
    let userInfo
    let filtered = arrFromLS.filter( e => {
        if(e.id == id) {
            userInfo = e
        }
    })
    return userInfo
}

function chengeDataLocalStorage(newUserInfo) {
    let dataArr = getDataArrayLocalStorage()
    dataArr.forEach((element, index )=> {
        if(newUserInfo.id == element.id){
            dataArr.splice(index, 1, newUserInfo)
        }
    saveToLocalStorage(dataArr)
    });
}

export {
    chengeDataLocalStorage,
    findDataLocalStorage,
    getDataArrayLocalStorage,
    addTask,
    locStorArr,
}